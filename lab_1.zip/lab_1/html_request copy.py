# %% Load library
import wget
import json
from requests_html import HTMLSession

# %% Build the session
session = HTMLSession()

# %% Request
URL = 'https://movie.thepan.cn/details.php?id=1'
r = session.get(URL)
print(r)

# %%
print(r.html.links)
print(r.html.absolute_links)

# %%
site_nav = r.html.find('.filterNav', first=True)
print(site_nav.html)
print(site_nav.text)

# %%
movie_titles = [movie.text for movie in r.html.find('h2')]
print(movie_titles)
print(len(movie_titles))

# %%
# print movie details 
movie_info = [movie.text for movie in r.html.find('p')]
print(movie_info)
print(len(movie_info))



# %%
output_file = 'movie.json'
movies = dict(zip(movie_titles, movie_info))

with open(output_file, 'w') as output_handler:
    json.dump(movies, output_handler, indent=4)


# %%


# %%
